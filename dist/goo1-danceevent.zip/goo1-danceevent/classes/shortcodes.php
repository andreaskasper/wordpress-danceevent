<?php

namespace plugins\goo1\danceevent;

class shortcodes {
	
  public static function render_livestream($atts, $content) {
    $round_id = $_GET["round"] ?? null;
	$html .= '';
	$html .= 'abc';
    return $html;
  }


}